"""
Corrected IoU bar chart for LEVIR-CD.
All values refer to change-class IoU (IoU_1).
SNUNet is omitted because its official code does not output IoU.
"""
import matplotlib.pyplot as plt

methods = [
    'DyT-KAN-HSN',
    'FC-Siam-Conc',
    'ChangeFormer',
    'FC-Siam-Diff',
    'Siam-NestedUNet',
    'BIT',
    'DSIFN',
    'STANet'
]
iou_scores = [
    0.8544,
    0.7976,
    0.7792,
    0.7741,
    0.5735,
    0.3003,
    0.0805,
    0.0000
]

colors = [
    '#d62728',
    '#1f77b4',
    '#ff7f0e',
    '#2ca02c',
    '#9467bd',
    '#e377c2',
    '#7f7f7f',
    '#bcbd22',
]

plt.figure(figsize=(14, 6))
bars = plt.bar(methods, iou_scores, color=colors, edgecolor='black', linewidth=0.8)

for bar, val in zip(bars, iou_scores):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 0.01,
        f'{val:.4f}',
        ha='center',
        va='bottom',
        fontsize=10,
        fontweight='bold'
    )

plt.ylabel('IoU', fontsize=12)
plt.title('IoU Comparison on LEVIR-CD', fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontsize=10)
plt.ylim(0, 0.95)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig('iou_bar_chart_updated.png', dpi=300, bbox_inches='tight')
print("Corrected IoU bar chart saved as iou_bar_chart_updated.png")