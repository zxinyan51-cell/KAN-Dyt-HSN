import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision.transforms import Compose, Resize, ToTensor, InterpolationMode
import numpy as np
import os
import sys
import argparse

sys.path.append('/root/autodl-tmp/RSE_experiments')
from cd_dataset import ChangeDetectionDataset, get_dataset_paths
from model_pixel import DyT_KAN_HSN_Pixel


def set_seed(seed):
    """设置所有随机种子确保可复现"""
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def dice_loss(pred, target):
    smooth = 1e-5
    pred = torch.sigmoid(pred)
    intersection = (pred * target).sum()
    union = pred.sum() + target.sum()
    return 1 - (2 * intersection + smooth) / (union + smooth)


def combined_loss(pred, target):
    bce = nn.functional.binary_cross_entropy_with_logits(pred, target)
    dice = dice_loss(pred, target)
    return bce + dice


def train_one_epoch(model, dataloader, optimizer, device):
    model.train()
    total_loss = 0
    for i, (t1, t2, label) in enumerate(dataloader):
        t1, t2, label = t1.to(device), t2.to(device), label.to(device)
        optimizer.zero_grad()
        out = model(t1, t2)
        loss = combined_loss(out, label)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        if i % 50 == 0:
            print(f"Batch {i}, Loss: {loss.item():.4f}")
    return total_loss / len(dataloader)


def evaluate(model, dataloader, device):
    model.eval()
    tp = fp = fn = tn = 0
    with torch.no_grad():
        for t1, t2, label in dataloader:
            t1, t2, label = t1.to(device), t2.to(device), label.to(device)
            out = model(t1, t2)
            pred = (torch.sigmoid(out) > 0.5).float()
            tp += (pred * label).sum().item()
            fp += (pred * (1 - label)).sum().item()
            fn += ((1 - pred) * label).sum().item()
            tn += ((1 - pred) * (1 - label)).sum().item()
    precision = tp / (tp + fp + 1e-7)
    recall = tp / (tp + fn + 1e-7)
    f1 = 2 * precision * recall / (precision + recall + 1e-7)
    iou = tp / (tp + fp + fn + 1e-7)
    return {"precision": precision, "recall": recall, "f1": f1, "iou": iou}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='LEVIR', help='LEVIR, WHU, DSIFN')
    parser.add_argument('--seed', type=int, default=42, help='random seed')
    args, _ = parser.parse_known_args()
    
    dataset_name = args.dataset
    seed = args.seed
    
    # 设置随机种子
    set_seed(seed)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    print(f"Dataset: {dataset_name}")
    print(f"Random seed: {seed}")

    batch_size = 8
    epochs = 50
    lr = 0.0001

    transform = Compose([Resize((256, 256)), ToTensor()])
    label_transform = Compose([
        Resize((256, 256), interpolation=InterpolationMode.NEAREST),
        ToTensor()
    ])

    paths = get_dataset_paths(dataset_name)

    train_ds = ChangeDetectionDataset(
        paths["train"][0], paths["train"][1], paths["train"][2],
        transform=transform,
        label_transform=label_transform,
    )
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=4)

    model = DyT_KAN_HSN_Pixel(pretrained=True).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)

    print(f"Start training {dataset_name} (seed={seed}), samples: {len(train_ds)}")

    best_f1 = 0.0

    for epoch in range(epochs):
        loss = train_one_epoch(model, train_loader, optimizer, device)
        metrics = evaluate(model, train_loader, device)
        print(f"Epoch {epoch}: Loss={loss:.4f}, F1={metrics['f1']:.4f}, IoU={metrics['iou']:.4f}")

        if metrics['f1'] > best_f1:
            best_f1 = metrics['f1']
            torch.save(model.state_dict(), f'dyt_kan_hsn_{dataset_name}_seed{seed}_best.pth')
            print(f"  -> Save best weights (F1={best_f1:.4f})")

    print("训练完成！")
    print(f"Seed {seed} best F1: {best_f1:.4f}")
    print(f"Weights saved as dyt_kan_hsn_{dataset_name}_seed{seed}_best.pth")