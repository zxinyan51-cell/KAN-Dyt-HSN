import os
from PIL import Image
import numpy as np

# LEVIR-CD 数据路径
LEVIR_ROOT = '/root/autodl-tmp/RSE_experiments/datasets/LEVIR-CD'

# 获取所有图片名（以 A 文件夹为准）
A_dir = os.path.join(LEVIR_ROOT, 'A')
B_dir = os.path.join(LEVIR_ROOT, 'B')
label_dir = os.path.join(LEVIR_ROOT, 'label')

img_names = sorted(os.listdir(A_dir))
print(f"总图片数: {len(img_names)}")
print(f"前 5 个图片名: {img_names[:5]}")

# 测试读取第一对图片
test_name = img_names[0]
img_A = Image.open(os.path.join(A_dir, test_name)).convert('RGB')
img_B = Image.open(os.path.join(B_dir, test_name)).convert('RGB')
img_label = Image.open(os.path.join(label_dir, test_name)).convert('L')

print(f"\n图片名: {test_name}")
print(f"A 图尺寸: {img_A.size}, 模式: {img_A.mode}")
print(f"B 图尺寸: {img_B.size}, 模式: {img_B.mode}")
print(f"标签尺寸: {img_label.size}, 模式: {img_label.mode}")

# 检查标签的取值范围
label_arr = np.array(img_label)
print(f"\n标签唯一值: {np.unique(label_arr)}")
print(f"标签最小值: {label_arr.min()}, 最大值: {label_arr.max()}")

# 统计正负样本比例
total_pixels = label_arr.size
change_pixels = (label_arr > 0).sum()
print(f"\n变化像素占比: {change_pixels / total_pixels * 100:.2f}%")

# 检查 A 和 B 是否同名对应
A_names = set(os.listdir(A_dir))
B_names = set(os.listdir(B_dir))
label_names = set(os.listdir(label_dir))
print(f"\nA 和 B 文件名一致: {A_names == B_names}")
print(f"A 和 label 文件名一致: {A_names == label_names}")

print("\n✅ LEVIR-CD 数据加载器测试通过")
