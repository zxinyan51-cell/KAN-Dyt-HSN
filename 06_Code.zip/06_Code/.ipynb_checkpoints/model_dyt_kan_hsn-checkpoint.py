import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
sys.path.append('/root/autodl-tmp/TreeChange')
from net.resnet import resnet18


# ========== DyT Module ==========
class DynamicTanh(nn.Module):
    def __init__(self, num_features, alpha_init=0.5):
        super().__init__()
        self.alpha = nn.Parameter(torch.ones(1) * alpha_init)
        self.weight = nn.Parameter(torch.ones(num_features))
        self.bias = nn.Parameter(torch.zeros(num_features))

    def forward(self, x):
        x = torch.tanh(self.alpha * x)
        return x * self.weight.view(1, -1, 1, 1) + self.bias.view(1, -1, 1, 1)


def replace_bn_with_dyt(module):
    for name, child in module.named_children():
        if isinstance(child, nn.BatchNorm2d):
            num_features = child.num_features
            setattr(module, name, DynamicTanh(num_features))
        else:
            replace_bn_with_dyt(child)


# ========== KAN Module (Hand-crafted Approximation) ==========
class KANBlock(nn.Module):
    def __init__(self, in_features, out_features, hidden_dim=256):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, out_features)
        self.norm = nn.LayerNorm(out_features)
        self.dropout = nn.Dropout(0.1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return self.norm(x)


# ========== Decoder Module ==========
class DecoderBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        x = self.up(x)
        x = self.conv(x)
        return x


# ========== Pixel-level DyT-KAN-HSN ==========
class DyT_KAN_HSN_Pixel(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        self.resnet = resnet18(pretrained=pretrained)
        replace_bn_with_dyt(self.resnet)
        del self.resnet.fc

        self.decoder = nn.Sequential(
            DecoderBlock(512, 256),
            DecoderBlock(256, 128),
            DecoderBlock(128, 64),
            DecoderBlock(64, 32),
            DecoderBlock(32, 16),
        )

        self.final_conv = nn.Conv2d(16, 1, kernel_size=1)

    def forward(self, t1, t2):
        _, feat1 = self.resnet(t1)
        _, feat2 = self.resnet(t2)

        diff = torch.abs(feat1 - feat2)

        x = self.decoder(diff)
        out = self.final_conv(x)

        return out


if __name__ == "__main__":
    model = DyT_KAN_HSN_Pixel(pretrained=True)
    t1 = torch.randn(2, 3, 256, 256)
    t2 = torch.randn(2, 3, 256, 256)
    out = model(t1, t2)
    print(f"Output shape: {out.shape}")