import torch
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from torchvision.transforms import Compose, Resize, ToTensor, InterpolationMode
import sys
import os
sys.path.append('/root/autodl-tmp/RSE_experiments')
sys.path.append('/root/autodl-tmp/RSE_experiments/methods/ChangeFormer')
sys.path.append('/root/autodl-tmp/RSE_experiments/methods')
from model_pixel import DyT_KAN_HSN_Pixel


def load_dyt_kan_hsn(dataset_name, device):
    """加载你的 DyT-KAN-HSN 模型"""
    model = DyT_KAN_HSN_Pixel(pretrained=True).to(device)
    weight_path = f'/root/autodl-tmp/RSE_experiments/dyt_kan_hsn_{dataset_name}_best.pth'
    checkpoint = torch.load(weight_path, map_location=device)
    model.load_state_dict(checkpoint)
    model.eval()
    return model


def load_changeformer(dataset_name, device):
    """加载 ChangeFormer 模型"""
    sys.path.append('/root/autodl-tmp/RSE_experiments/methods/ChangeFormer')
    from models.networks import ChangeFormerV6
    
    model = ChangeFormerV6(embed_dim=256, output_nc=2).to(device)
    checkpoint_root = f'/root/autodl-tmp/RSE_experiments/methods/ChangeFormer/checkpoints'
    
    # 找到对应的检查点目录
    import glob
    dirs = glob.glob(f'{checkpoint_root}/CD_ChangeFormerV6_{dataset_name}*/')
    if dirs:
        ckpt_path = os.path.join(dirs[0], 'best_ckpt.pt')
        if os.path.exists(ckpt_path):
            checkpoint = torch.load(ckpt_path, map_location=device)
            model.load_state_dict(checkpoint['model_G_state_dict'])
            print(f"ChangeFormer 权重已加载: {ckpt_path}")
    model.eval()
    return model


def load_snunet(device):
    """加载 SNUNet 模型"""
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        'Models',
        '/root/autodl-tmp/RSE_experiments/methods/Siam-NestedUNet/models/Models.py'
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    SNUNet_ECAM = module.SNUNet_ECAM
    sys.modules['models'] = module
    sys.modules['models.Models'] = module
    
    model = SNUNet_ECAM(3, 2).to(device)
    # SNUNet 权重在 tmp/ 下的最新 epoch
    ckpt_path = '/root/autodl-tmp/RSE_experiments/methods/Siam-NestedUNet/tmp/checkpoint_epoch_49.pt'
    if os.path.exists(ckpt_path):
        model = torch.load(ckpt_path, map_location=device)
        print("SNUNet 模型已加载")
    model.eval()
    return model


def predict_dyt_kan(model, t1, t2, device):
    with torch.no_grad():
        out = model(t1.unsqueeze(0).to(device), t2.unsqueeze(0).to(device))
        prob = torch.sigmoid(out).squeeze().cpu().numpy()
        return (prob > 0.5).astype(np.uint8)


def predict_changeformer(model, t1, t2, device):
    with torch.no_grad():
        out = model(t1.unsqueeze(0).to(device), t2.unsqueeze(0).to(device))
        # ChangeFormer 返回 list，取最后一个输出
        if isinstance(out, list):
            out = out[-1]
        pred = torch.argmax(out, dim=1).squeeze().cpu().numpy()
        return pred.astype(np.uint8)


def predict_snunet(model, t1, t2, device):
    with torch.no_grad():
        out = model(t1.unsqueeze(0).to(device), t2.unsqueeze(0).to(device))
        # SNUNet 返回 tuple，取第一个输出
        if isinstance(out, tuple):
            out = out[0]
        pred = torch.argmax(out, dim=1).squeeze().cpu().numpy()
        return pred.astype(np.uint8)


def visualize_comparison(dataset_name, sample_idx=0):
    device = torch.device('cuda:0')
    
    # 加载三个模型
    print("加载模型...")
    model_dyt = load_dyt_kan_hsn(dataset_name, device)
    model_cf = load_changeformer(dataset_name, device)
    model_sn = load_snunet(device)
    
    # 加载数据
    transform = Compose([Resize((256, 256)), ToTensor()])
    sys.path.append('/root/autodl-tmp/RSE_experiments')
    from cd_dataset import ChangeDetectionDataset, get_dataset_paths
    
    paths = get_dataset_paths(dataset_name)
    ds = ChangeDetectionDataset(
        paths['train'][0], paths['train'][1], paths['train'][2],
        transform=transform,
        label_transform=Compose([Resize((256, 256), interpolation=InterpolationMode.NEAREST), ToTensor()])
    )
    
    # 找一个有变化的样本
    found = False
    for i in range(len(ds)):
        t1, t2, label = ds[i]
        ratio = (label > 0.5).float().mean().item()
        if ratio > 0.15:
            sample_idx = i
            found = True
            break
    
    t1, t2, label = ds[sample_idx]
    print(f"使用样本 index={sample_idx}, 变化比例={(label>0.5).float().mean().item():.4f}")
    
    # 预测
    pred_dyt = predict_dyt_kan(model_dyt, t1, t2, device)
    pred_cf = predict_changeformer(model_cf, t1, t2, device)
    pred_sn = predict_snunet(model_sn, t1, t2, device)
    
    # 转换格式
    t1_np = t1.permute(1, 2, 0).numpy()
    t2_np = t2.permute(1, 2, 0).numpy()
    label_np = label.squeeze().numpy()
    
    # 绘制
    fig, axes = plt.subplots(1, 6, figsize=(24, 5))
    
    titles = ['t1', 't2', 'Ground Truth', 'DyT-KAN-HSN', 'ChangeFormer', 'SNUNet']
    images = [t1_np, t2_np, label_np, pred_dyt, pred_cf, pred_sn]
    cmaps = [None, None, 'gray', 'gray', 'gray', 'gray']
    
    for ax, title, img, cmap in zip(axes, titles, images, cmaps):
        if cmap:
            ax.imshow(img, cmap=cmap)
        else:
            ax.imshow(img)
        ax.set_title(title, fontsize=11, fontweight='bold')
        ax.axis('off')
    
    plt.tight_layout()
    plt.savefig(f'prediction_comparison_{dataset_name}.png', dpi=300, bbox_inches='tight')
    print(f"预测对比图已保存为 prediction_comparison_{dataset_name}.png")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='WHU')
    args = parser.parse_args()
    visualize_comparison(args.dataset)