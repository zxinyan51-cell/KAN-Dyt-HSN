import re
import matplotlib.pyplot as plt

def extract_loss(log_path):
    """提取自己写的训练脚本的 Loss"""
    losses = []
    with open(log_path, 'r') as f:
        for line in f:
            m = re.search(r'Epoch (\d+): Loss=([\d.]+)', line)
            if m:
                losses.append(float(m.group(2)))
    return losses

# 提取所有方法的 Loss
dyt_kan = extract_loss('/root/autodl-tmp/RSE_experiments/train_LEVIR_weighted.log')
siam_nested = extract_loss('/root/autodl-tmp/RSE_experiments/train_SiamNestedUNet_LEVIR.log')
fc_conc = extract_loss('/root/autodl-tmp/RSE_experiments/train_FCSiamConc_LEVIR.log')
fc_diff = extract_loss('/root/autodl-tmp/RSE_experiments/train_FCSiamDiff_LEVIR.log')

plt.figure(figsize=(12, 6))
plt.plot(dyt_kan, label='DyT-KAN-HSN', linewidth=2, color='#d62728')
plt.plot(siam_nested, label='Siam-NestedUNet', linewidth=2, color='#1f77b4')
plt.plot(fc_conc, label='FC-Siam-Conc', linewidth=2, color='#2ca02c')
plt.plot(fc_diff, label='FC-Siam-Diff', linewidth=2, color='#9467bd')

plt.xlabel('Epoch', fontsize=12)
plt.ylabel('Training Loss', fontsize=12)
plt.title('Training Loss Comparison on LEVIR-CD', fontsize=14, fontweight='bold')
plt.legend(fontsize=11)
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig('loss_curve_updated.png', dpi=300, bbox_inches='tight')
print("Loss 曲线已保存为 loss_curve_updated.png")