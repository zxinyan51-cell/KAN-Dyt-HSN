"""
Corrected F1 bar chart for LEVIR-CD.
All values refer to change-class F1 (F1_1).
"""
import matplotlib.pyplot as plt
import numpy as np

methods = [
    'DyT-KAN-HSN',
    'FC-Siam-Conc',
    'ChangeFormer',
    'FC-Siam-Diff',
    'Siam-NestedUNet',
    'SNUNet',
    'BIT',
    'DSIFN',
    'STANet'
]
f1_scores = [
    0.9215,
    0.8874,
    0.8759,
    0.8727,
    0.7289,
    0.7033,
    0.4619,
    0.1489,
    0.0000
]

colors = [
    '#d62728',
    '#1f77b4',
    '#ff7f0e',
    '#2ca02c',
    '#9467bd',
    '#8c564b',
    '#e377c2',
    '#7f7f7f',
    '#bcbd22',
]

plt.figure(figsize=(14, 6))
bars = plt.bar(methods, f1_scores, color=colors, edgecolor='black', linewidth=0.8)

for bar, val in zip(bars, f1_scores):
    plt.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 0.01,
        f'{val:.4f}',
        ha='center',
        va='bottom',
        fontsize=10,
        fontweight='bold'
    )

plt.ylabel('F1-score', fontsize=12)
plt.title('F1-score Comparison on LEVIR-CD', fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontsize=10)
plt.ylim(0, 1.05)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig('f1_bar_chart_updated.png', dpi=300, bbox_inches='tight')
print("Corrected F1 bar chart saved as f1_bar_chart_updated.png")