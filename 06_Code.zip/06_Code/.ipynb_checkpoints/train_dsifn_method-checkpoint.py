import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision.transforms import Compose, Resize, ToTensor, InterpolationMode
import numpy as np
import sys
import os

sys.path.append('/root/autodl-tmp/RSE_experiments')
sys.path.append('/root/autodl-tmp/RSE_experiments/methods/A-deeply-supervised-image-fusion-network-for-change-detection-in-remote-sensing-images/pytorch version')
from cd_dataset import ChangeDetectionDataset, get_dataset_paths
from DSIFN import DSIFN, vgg16_base


def dice_loss(pred, target):
    smooth = 1e-5
    pred = torch.sigmoid(pred)
    intersection = (pred * target).sum()
    union = pred.sum() + target.sum()
    return 1 - (2 * intersection + smooth) / (union + smooth)


def combined_loss(pred, target):
    bce = nn.functional.binary_cross_entropy_with_logits(pred, target)
    dice = dice_loss(pred, target)
    return bce + dice


def train_one_epoch(model, dataloader, optimizer, device):
    model.train()
    total_loss = 0
    for t1, t2, label in dataloader:
        t1, t2, label = t1.to(device), t2.to(device), label.to(device)
        optimizer.zero_grad()
        outputs = model(t1, t2)
        # DSIFN returns multiple branch outputs; take the last (final output)
        if isinstance(outputs, tuple):
            out = outputs[-1]
        else:
            out = outputs
        out = nn.functional.interpolate(out, size=(256, 256), mode="bilinear", align_corners=True)
        loss = combined_loss(out, label)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(dataloader)


def evaluate(model, dataloader, device):
    model.eval()
    tp = fp = fn = tn = 0
    with torch.no_grad():
        for t1, t2, label in dataloader:
            t1, t2, label = t1.to(device), t2.to(device), label.to(device)
            outputs = model(t1, t2)
            if isinstance(outputs, tuple):
                out = outputs[-1]
            else:
                out = outputs
            out = nn.functional.interpolate(out, size=(256, 256), mode="bilinear", align_corners=True)
            pred = (torch.sigmoid(out) > 0.5).float()
            tp += (pred * label).sum().item()
            fp += (pred * (1 - label)).sum().item()
            fn += ((1 - pred) * label).sum().item()
            tn += ((1 - pred) * (1 - label)).sum().item()
    precision = tp / (tp + fp + 1e-7)
    recall = tp / (tp + fn + 1e-7)
    f1 = 2 * precision * recall / (precision + recall + 1e-7)
    iou = tp / (tp + fp + fn + 1e-7)
    return {"precision": precision, "recall": recall, "f1": f1, "iou": iou}


if __name__ == "__main__":
    device = torch.device('cuda:0')
    dataset_name = 'LEVIR'
    
    transform = Compose([Resize((256, 256)), ToTensor()])
    label_transform = Compose([Resize((256, 256), interpolation=InterpolationMode.NEAREST), ToTensor()])
    
    paths = get_dataset_paths(dataset_name)
    ds = ChangeDetectionDataset(paths['train'][0], paths['train'][1], paths['train'][2],
                                transform=transform, label_transform=label_transform)
    loader = DataLoader(ds, batch_size=8, shuffle=True, num_workers=4)
    
    # Initialize two VGG16 backbones (shared weights)
    base_a = vgg16_base().to(device)
    base_b = vgg16_base().to(device)
    
    model = DSIFN(base_a, base_b).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.0001)
    
    print(f"Start training DSIFN, samples: {len(ds)}")
    
    for epoch in range(50):
        loss = train_one_epoch(model, loader, optimizer, device)
        metrics = evaluate(model, loader, device)
        print(f"Epoch {epoch}: Loss={loss:.4f}, F1={metrics['f1']:.4f}, IoU={metrics['iou']:.4f}")
    
    torch.save(model.state_dict(), f'dsifn_{dataset_name}_best.pth')
    print("Training completed, weights saved")