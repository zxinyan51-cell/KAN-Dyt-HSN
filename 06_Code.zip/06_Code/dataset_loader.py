import os
import torch
from torch.utils.data import Dataset
from PIL import Image
import numpy as np


class ChangeDetectionDataset(Dataset):
    """
    Generic change detection dataset loader
    Supports LEVIR-CD256, WHU-CD, and DSIFN-CD datasets
    """

    def __init__(self, t1_dir, t2_dir, label_dir, transform=None, label_transform=None):
        self.t1_dir = t1_dir
        self.t2_dir = t2_dir
        self.label_dir = label_dir
        self.transform = transform
        self.label_transform = label_transform

        def get_stem(f):
            return os.path.splitext(f)[0]

        self.t1_files = {get_stem(f): f for f in os.listdir(t1_dir)}
        self.t2_files = {get_stem(f): f for f in os.listdir(t2_dir)}
        self.label_files = {get_stem(f): f for f in os.listdir(label_dir)}

        common_stems = sorted(
            set(self.t1_files.keys()) &
            set(self.t2_files.keys()) &
            set(self.label_files.keys())
        )
        self.image_names = common_stems

        print(f"Dataset loaded:{len(self.image_names)} image pairs")

    def __len__(self):
        return len(self.image_names)

    def __getitem__(self, idx):
        stem = self.image_names[idx]

        t1_path = os.path.join(self.t1_dir, self.t1_files[stem])
        t2_path = os.path.join(self.t2_dir, self.t2_files[stem])
        label_path = os.path.join(self.label_dir, self.label_files[stem])

        t1_img = Image.open(t1_path).convert('RGB')
        t2_img = Image.open(t2_path).convert('RGB')
        label_img = Image.open(label_path)
        if label_img.mode != 'L':
            label_img = label_img.convert('L')

        if self.transform:
            t1_img = self.transform(t1_img)
            t2_img = self.transform(t2_img)
        else:
            from torchvision.transforms import ToTensor
            t1_img = ToTensor()(t1_img)
            t2_img = ToTensor()(t2_img)

        # Binarize label map: nonzero pixels set to 255
        label_img = label_img.point(lambda p: 255 if p > 0 else 0)

        if self.label_transform:
            label = self.label_transform(label_img)
        else:
            from torchvision.transforms import ToTensor
            label = ToTensor()(label_img)

        label = (label > 0.5).float()
        return t1_img, t2_img, label


def get_dataset_paths(dataset_name, root="/root/autodl-tmp/RSE_experiments/datasets"):
    if dataset_name == "LEVIR":
        base = os.path.join(root, "LEVIR-CD256")
        return {
            "train": (os.path.join(base, "A"), os.path.join(base, "B"), os.path.join(base, "label")),
            "test": (os.path.join(base, "A"), os.path.join(base, "B"), os.path.join(base, "label")),
        }

    elif dataset_name == "WHU":
        base = os.path.join(root, "WHU-CD", "Building change detection dataset_add", "1. The two-period image data")
        return {
            "train": (
                os.path.join(base, "2012/splited_images/train/image"),
                os.path.join(base, "2016/splited_images/train/image"),
                os.path.join(base, "change_label/train/sliced"),
            ),
            "test": (
                os.path.join(base, "2012/splited_images/train/image"),
                os.path.join(base, "2016/splited_images/train/image"),
                os.path.join(base, "change_label/train/sliced"),
            ),
        }

    elif dataset_name == "DSIFN":
        train_base = os.path.join(root, "DSIFN-CD", "DSIFN-Dataset", "train")
        test_base = os.path.join(root, "DSIFN-CD", "DSIFN-Dataset", "test")
        return {
            "train": (
                os.path.join(train_base, "t1"),
                os.path.join(train_base, "t2"),
                os.path.join(train_base, "mask"),
            ),
            "test": (
                os.path.join(test_base, "t1"),
                os.path.join(test_base, "t2"),
                os.path.join(test_base, "mask"),
            ),
        }

    else:
        raise ValueError(f"Unknown dataset: {dataset_name}")


if __name__ == "__main__":
    from torchvision.transforms import Compose, Resize, ToTensor

    transform = Compose([Resize((256, 256)), ToTensor()])

    for name in ["LEVIR", "WHU", "DSIFN"]:
        paths = get_dataset_paths(name)
        ds = ChangeDetectionDataset(
            paths["train"][0],
            paths["train"][1],
            paths["train"][2],
            transform=transform,
        )
        print(f"{name} training samples: {len(ds)}")

        t1, t2, label = ds[0]
        print(f"  t1 shape: {t1.shape}, label shape: {label.shape}")