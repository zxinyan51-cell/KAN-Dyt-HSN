import torch
import numpy as np
from PIL import Image
import os
import sys
sys.path.append('/root/autodl-tmp/RSE_experiments/methods/STANet')
from models import create_model
import argparse

def evaluate_stanet(dataset_dir, checkpoint_dir, name):
    """Evaluate STANet F1 and IoU on LEVIR test set"""
    
    # Load model
    opt = argparse.Namespace(
        model='CDFA',
        SA_mode='PAM',
        arch='mynet3',
        f_c=64,
        n_class=2,
        gpu_ids='0',
        checkpoints_dir=checkpoint_dir,
        name=name,
        epoch='latest',
        isTrain=False,
        input_nc=3,
        output_nc=2,
        dataset_mode='changedetection',
        angle=0,
        ds=1,
        preprocess='resize_and_crop',
        load_size=256,
        crop_size=256,
        phase='test',
        batch_size=1,
        num_threads=0,
        load_iter=0,
        verbose=False,
    )
    
    model = create_model(opt)
    model.setup(opt)
    model.eval()
    
    # Metrics counters
    tp = fp = fn = tn = 0
    
    # Test images
    test_a_dir = f'{dataset_dir}/A/'
    test_b_dir = f'{dataset_dir}/B/'
    label_dir = f'{dataset_dir}/label/'
    
    files = sorted(os.listdir(test_a_dir))
    print(f"Test samples: {len(files)}")
    
    from torchvision.transforms import ToTensor, Resize
    transform = ToTensor()
    
    with torch.no_grad():
        for idx, fname in enumerate(files):
            img1 = Image.open(os.path.join(test_a_dir, fname)).convert('RGB')
            img2 = Image.open(os.path.join(test_b_dir, fname)).convert('RGB')
            label = Image.open(os.path.join(label_dir, fname)).convert('L')
            
            A = transform(img1).unsqueeze(0)
            B = transform(img2).unsqueeze(0)
            
            data = {'A': A, 'B': B, 'A_paths': [fname], 'B_paths': [fname]}
            model.set_input(data)
            pred = model.test(val=False)
            
            # Take change class probability
            pred = torch.argmax(pred, dim=1).squeeze().cpu().numpy()
            label_np = (np.array(label) > 0).astype(np.uint8)
            
            tp += ((pred == 1) & (label_np == 1)).sum()
            fp += ((pred == 1) & (label_np == 0)).sum()
            fn += ((pred == 0) & (label_np == 1)).sum()
            tn += ((pred == 0) & (label_np == 0)).sum()
            
            if (idx + 1) % 500 == 0:
                print(f"  Processed {idx+1}/{len(files)}")
    
    precision = tp / (tp + fp + 1e-7)
    recall = tp / (tp + fn + 1e-7)
    f1 = 2 * precision * recall / (precision + recall + 1e-7)
    iou = tp / (tp + fp + fn + 1e-7)
    
    print(f"\n===== STANet LEVIR Evaluation Results =====")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1-score: {f1:.4f}")
    print(f"IoU: {iou:.4f}")
    print(f"================================")


if __name__ == "__main__":
    evaluate_stanet(
        dataset_dir='/root/autodl-tmp/RSE_experiments/datasets/LEVIR-CD256',
        checkpoint_dir='/root/autodl-tmp/RSE_experiments/methods/STANet/checkpoints',
        name='STANet_LEVIR'
    )