import matplotlib.pyplot as plt
import numpy as np

# Dataset statistics (real data)
datasets = ['LEVIR-CD', 'DSIFN-CD', 'WHU-CD']
samples = [10192, 3600, 1189]
change_ratios = [0.0557, 0.2155, 0.0497]  # Actual change pixel ratio

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Subplot 1: sample count
bars1 = axes[0].bar(datasets, samples, color=['#1f77b4', '#ff7f0e', '#2ca02c'], edgecolor='black', linewidth=0.8)
axes[0].set_title('Dataset Size', fontsize=13, fontweight='bold')
axes[0].set_ylabel('Number of Image Pairs', fontsize=11)
axes[0].grid(axis='y', linestyle='--', alpha=0.5)
for bar, v in zip(bars1, samples):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 100, 
                 str(v), ha='center', va='bottom', fontsize=11, fontweight='bold')

# Subplot 2: change pixel ratio
bars2 = axes[1].bar(datasets, [r*100 for r in change_ratios], 
                    color=['#1f77b4', '#ff7f0e', '#d62728'], edgecolor='black', linewidth=0.8)
axes[1].set_title('Change Pixel Ratio (%)', fontsize=13, fontweight='bold')
axes[1].set_ylabel('Percentage (%)', fontsize=11)
axes[1].grid(axis='y', linestyle='--', alpha=0.5)
for bar, r in zip(bars2, change_ratios):
    axes[1].text(bar.get_x() + bar.get_width()/2, r*100 + 0.3, 
                 f'{r*100:.2f}%', ha='center', va='bottom', fontsize=11, fontweight='bold')

plt.tight_layout()
plt.savefig('dataset_statistics.png', dpi=300, bbox_inches='tight')
print("Dataset statistics saved as dataset_statistics.png")