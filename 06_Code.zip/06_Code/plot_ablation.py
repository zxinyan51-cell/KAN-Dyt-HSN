import matplotlib.pyplot as plt
import numpy as np

# Ablation study data
models = ['HSN (Baseline)', 'DyT-HSN', 'KAN-HSN', 'DyT-KAN-HSN']
acc = [0.7645, 0.7552, 0.8249, 0.8844]
f1 = [0.5598, 0.2295, 0.6156, 0.7725]

x = np.arange(len(models))
width = 0.35

fig, ax = plt.figure(figsize=(10, 6)), plt.axes()

# ACC bar chart
bars_acc = ax.bar(x - width/2, acc, width, label='ACC', color='#1f77b4', edgecolor='black', linewidth=0.8)
# F1 bar chart
bars_f1 = ax.bar(x + width/2, f1, width, label='F1', color='#ff7f0e', edgecolor='black', linewidth=0.8)

# Annotate values
for bar, val in zip(bars_acc, acc):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
            f'{val:.4f}', ha='center', va='bottom', fontsize=9)
for bar, val in zip(bars_f1, f1):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
            f'{val:.4f}', ha='center', va='bottom', fontsize=9)

ax.set_xlabel('Model Variants', fontsize=12)
ax.set_ylabel('Score', fontsize=12)
ax.set_xticks(x)
ax.set_xticklabels(models, fontsize=10)
ax.set_ylim(0, 1.0)
ax.grid(axis='y', linestyle='--', alpha=0.5)
ax.legend(fontsize=11)

plt.tight_layout()
plt.savefig('ablation_bar_chart.png', dpi=300, bbox_inches='tight')
print("Ablation bar chart saved as ablation_bar_chart.png")