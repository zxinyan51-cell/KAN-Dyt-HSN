import torch
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from torchvision.transforms import Compose, Resize, ToTensor, InterpolationMode
import sys
import os
sys.path.append('/root/autodl-tmp/RSE_experiments')
from model_pixel import DyT_KAN_HSN_Pixel


def visualize_heatmap(t1_path, t2_path, label_path, dataset_name, output_name):
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    
    # Load model
    model = DyT_KAN_HSN_Pixel(pretrained=True).to(device)
    weight_path = f'/root/autodl-tmp/RSE_experiments/dyt_kan_hsn_{dataset_name}_best.pth'
    checkpoint = torch.load(weight_path, map_location=device)
    model.load_state_dict(checkpoint)
    model.eval()
    
    # Load images
    transform = Compose([Resize((256, 256)), ToTensor()])
    img1 = Image.open(t1_path).convert('RGB')
    img2 = Image.open(t2_path).convert('RGB')
    label = Image.open(label_path).convert('L')
    label = label.resize((256, 256), Image.NEAREST)
    
    img1_t = transform(img1).unsqueeze(0).to(device)
    img2_t = transform(img2).unsqueeze(0).to(device)
    
    # Forward pass to obtain change probability map
    with torch.no_grad():
        output = model(img1_t, img2_t)
        prob_map = torch.sigmoid(output).squeeze().cpu().numpy()
    
    # Normalize
    prob_map = (prob_map - prob_map.min()) / (prob_map.max() - prob_map.min() + 1e-8)
    
    # Plot
    plt.figure(figsize=(20, 5))
    
    plt.subplot(1, 4, 1)
    plt.imshow(img1)
    plt.title('t1 Image', fontsize=12)
    plt.axis('off')
    
    plt.subplot(1, 4, 2)
    plt.imshow(img2)
    plt.title('t2 Image', fontsize=12)
    plt.axis('off')
    
    plt.subplot(1, 4, 3)
    plt.imshow(label, cmap='gray')
    plt.title('Ground Truth', fontsize=12)
    plt.axis('off')
    
    plt.subplot(1, 4, 4)
    plt.imshow(img1)
    plt.imshow(prob_map, cmap='jet', alpha=0.6)
    plt.title('Change Probability Heatmap', fontsize=12)
    plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(output_name, dpi=300, bbox_inches='tight')
    print(f"Heatmap saved as {output_name}")


def find_change_sample(dataset_name, min_ratio=0.15):
    """Find a sample with high change ratio"""
    from torchvision.transforms import Compose, Resize, ToTensor, InterpolationMode
    sys.path.append('/root/autodl-tmp/RSE_experiments')
    from cd_dataset import ChangeDetectionDataset, get_dataset_paths
    
    transform = Compose([Resize((256, 256)), ToTensor()])
    label_transform = Compose([Resize((256, 256), interpolation=InterpolationMode.NEAREST), ToTensor()])
    paths = get_dataset_paths(dataset_name)
    ds = ChangeDetectionDataset(paths['train'][0], paths['train'][1], paths['train'][2],
                                transform=transform, label_transform=label_transform)
    
    for i in range(len(ds)):
        _, _, label = ds[i]
        ratio = (label > 0.5).float().mean().item()
        if ratio > min_ratio:
            return i, ratio
    return 0, 0.0


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='LEVIR')
    args = parser.parse_args()
    
    dataset_name = args.dataset
    
    # Automatically find a sample with obvious change
    idx, ratio = find_change_sample(dataset_name, min_ratio=0.15)
    print(f"Found changed sample: index={idx}, change ratio={ratio:.4f}")
    
    # Build paths based on dataset
    if dataset_name == 'LEVIR':
        base = '/root/autodl-tmp/RSE_experiments/datasets/LEVIR-CD256'
        # Get file names
        import os
        files = sorted(os.listdir(f'{base}/A'))
        sample = files[idx % len(files)]
        t1_path = f'{base}/A/{sample}'
        t2_path = f'{base}/B/{sample}'
        label_path = f'{base}/label/{sample}'
    elif dataset_name == 'DSIFN':
        base = '/root/autodl-tmp/RSE_experiments/datasets/DSIFN-CD/DSIFN-Dataset/train'
        import os
        files = sorted(os.listdir(f'{base}/t1'))
        sample = files[idx % len(files)]
        t1_path = f'{base}/t1/{sample}'
        t2_path = f'{base}/t2/{sample}'
        label_path = f'{base}/mask/{sample.replace(".jpg", ".png")}'
    else:  # WHU
        base = '/root/autodl-tmp/RSE_experiments/datasets/WHU-CD/Building change detection dataset_add/1. The two-period image data'
        import os
        files = sorted(os.listdir(f'{base}/2012/splited_images/train/image'))
        sample = files[idx % len(files)]
        t1_path = f'{base}/2012/splited_images/train/image/{sample}'
        t2_path = f'{base}/2016/splited_images/train/image/{sample}'
        label_path = f'{base}/change_label/train/sliced/{sample}'
    
    visualize_heatmap(t1_path, t2_path, label_path, dataset_name, f'heatmap_{dataset_name}.png')