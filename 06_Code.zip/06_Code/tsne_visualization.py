import torch
import numpy as np
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from torchvision.transforms import Compose, Resize, ToTensor, InterpolationMode
from torch.utils.data import DataLoader, Subset
import sys
import os
sys.path.append('/root/autodl-tmp/RSE_experiments')
from cd_dataset import ChangeDetectionDataset, get_dataset_paths
from model_pixel import DyT_KAN_HSN_Pixel


def extract_features(model, dataloader, device):
    """Extract features from all test samples"""
    model.eval()
    features = []
    labels_list = []
    with torch.no_grad():
        for t1, t2, label in dataloader:
            t1, t2 = t1.to(device), t2.to(device)
            # Extract features from the last layer of the backbone
            _, feat1 = model.resnet(t1)
            _, feat2 = model.resnet(t2)
            diff = torch.abs(feat1 - feat2)
            # Global average pooling to obtain feature vector
            feat = diff.mean(dim=[2, 3])
            features.append(feat.cpu().numpy())
            # Change pixel ratio -> binary label
            change_ratio = (label > 0.5).float().mean(dim=[1,2,3]).numpy()
            has_change = (change_ratio > 0.001).astype(float)
            labels_list.append(has_change)
    features = np.concatenate(features, axis=0)
    labels = np.concatenate(labels_list, axis=0)
    return features, labels


def tsne_visualize(dataset_name):
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    
    transform = Compose([Resize((256, 256)), ToTensor()])
    label_transform = Compose([
        Resize((256, 256), interpolation=InterpolationMode.NEAREST),
        ToTensor()
    ])
    
    paths = get_dataset_paths(dataset_name)
    ds = ChangeDetectionDataset(
        paths['train'][0], paths['train'][1], paths['train'][2],
        transform=transform,
        label_transform=label_transform,
    )
    
    # Randomly sample 500 images
    indices = np.random.choice(len(ds), min(500, len(ds)), replace=False)
    ds_sub = Subset(ds, indices)
    loader = DataLoader(ds_sub, batch_size=16, shuffle=False)
    
    # Load trained model weights
    model = DyT_KAN_HSN_Pixel(pretrained=True).to(device)
    weight_path = f'/root/autodl-tmp/RSE_experiments/dyt_kan_hsn_{dataset_name}_best.pth'
    
    if os.path.exists(weight_path):
        checkpoint = torch.load(weight_path, map_location=device)
        model.load_state_dict(checkpoint)
        print(f"Weights loaded: {weight_path}")
    else:
        print(f"Warning: weight file not found {weight_path}, using randomly initialized model")
    
    features, labels = extract_features(model, loader, device)
    
    print(f"Total samples: {len(features)}")
    print(f"Changed samples: {labels.sum():.0f}")
    print(f"Unchanged samples: {(1-labels).sum():.0f}")
    
    # t-SNE dimensionality reduction
    print("Running t-SNE...")
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    features_2d = tsne.fit_transform(features)
    
    # Plot
    plt.figure(figsize=(10, 8))
    plt.scatter(features_2d[labels < 0.5, 0], features_2d[labels < 0.5, 1],
                c='blue', label='No Change', alpha=0.6, s=30)
    plt.scatter(features_2d[labels >= 0.5, 0], features_2d[labels >= 0.5, 1],
                c='red', label='Change', alpha=0.6, s=30)
    plt.legend(fontsize=12)
    plt.title(f'DyT-KAN-HSN t-SNE Feature Distribution ({dataset_name})', fontsize=14)
    plt.xlabel('t-SNE Dimension 1', fontsize=12)
    plt.ylabel('t-SNE Dimension 2', fontsize=12)
    plt.tight_layout()
    plt.savefig(f'tsne_{dataset_name}_weighted.png', dpi=300, bbox_inches='tight')
    print(f"Figure saved as tsne_{dataset_name}_weighted.png")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='LEVIR')
    args = parser.parse_args()
    tsne_visualize(args.dataset)