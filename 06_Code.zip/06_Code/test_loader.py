import os
from PIL import Image
import numpy as np

# LEVIR-CD data path
LEVIR_ROOT = '/root/autodl-tmp/RSE_experiments/datasets/LEVIR-CD'

# Get all image names (based on folder A)
A_dir = os.path.join(LEVIR_ROOT, 'A')
B_dir = os.path.join(LEVIR_ROOT, 'B')
label_dir = os.path.join(LEVIR_ROOT, 'label')

img_names = sorted(os.listdir(A_dir))
print(f"Total images: {len(img_names)}")
print(f"First 5 image names: {img_names[:5]}")

# Test reading the first image pair
test_name = img_names[0]
img_A = Image.open(os.path.join(A_dir, test_name)).convert('RGB')
img_B = Image.open(os.path.join(B_dir, test_name)).convert('RGB')
img_label = Image.open(os.path.join(label_dir, test_name)).convert('L')

print(f"\nImage name: {test_name}")
print(f"A size: {img_A.size}, mode: {img_A.mode}")
print(f"B size: {img_B.size}, mode: {img_B.mode}")
print(f"Label size: {img_label.size}, mode: {img_label.mode}")

# Check label value range
label_arr = np.array(img_label)
print(f"\nLabel unique values: {np.unique(label_arr)}")
print(f"Label min: {label_arr.min()}, max: {label_arr.max()}")

# Count positive/negative sample ratio
total_pixels = label_arr.size
change_pixels = (label_arr > 0).sum()
print(f"\nChange pixel ratio: {change_pixels / total_pixels * 100:.2f}%")

# Check if A and B have matching file names
A_names = set(os.listdir(A_dir))
B_names = set(os.listdir(B_dir))
label_names = set(os.listdir(label_dir))
print(f"\nA and B names match: {A_names == B_names}")
print(f"A and label names match: {A_names == label_names}")

print("\nLEVIR-CD data loader test passed")
