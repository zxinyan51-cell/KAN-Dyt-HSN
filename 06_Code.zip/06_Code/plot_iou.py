import matplotlib.pyplot as plt
import numpy as np

methods = ['DyT-KAN-HSN', 'Siam-NestedUNet', 'ChangeFormer', 'FC-Siam-Conc',
           'FC-Siam-Diff', 'BIT']
iou_scores = [0.854, 0.798, 0.779, 0.774, 0.774, 0.300]
colors = ['#d62728', '#1f77b4', '#ff7f0e', '#2ca02c', '#9467bd', '#e377c2']

plt.figure(figsize=(12, 6))
bars = plt.bar(methods, iou_scores, color=colors, edgecolor='black', linewidth=0.8)

for bar, val in zip(bars, iou_scores):
    plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
             f'{val:.3f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

plt.ylabel('IoU', fontsize=12)
plt.title('IoU Comparison on LEVIR-CD', fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontsize=9)
plt.ylim(0, 0.95)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig('iou_bar_chart_updated.png', dpi=300, bbox_inches='tight')
print("IoU bar chart saved as iou_bar_chart_updated.png")